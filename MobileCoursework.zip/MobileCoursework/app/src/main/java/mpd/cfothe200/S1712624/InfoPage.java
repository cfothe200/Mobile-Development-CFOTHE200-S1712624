package mpd.cfothe200.S1712624;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class InfoPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_page);

        TextView text = (TextView) findViewById(R.id.eqLocation);
        Bundle view =getIntent().getExtras();
        text.setText(view.getString("quake"));
    }
}
