//Name: Christopher Fotheringham
//Student ID:S1712624
//Course: BSC Computing

package mpd.cfothe200.S1712624;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.LinkedList;

import static java.security.AccessController.getContext;

public class EarthquakeAdapter extends BaseAdapter {

    private Context eqContext;
    private LinkedList<Earthquake> eAllEQ;

    //create constructor

    public EarthquakeAdapter(Context eqContext,LinkedList<Earthquake> eAllEQ){

        this.eqContext = eqContext;
        this.eAllEQ = eAllEQ;

    }//end of earthquake adapter

    @Override
    public int getCount(){
        return eAllEQ.size();

    }//end of get count

    //get item - return item postition
    @Override
    public Object getItem(int position){return eAllEQ.get(position);}

    //get item id - return item position
    @Override
    public long getItemId(int position){return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null)
        {
            convertView = LayoutInflater.from(eqContext).inflate(R.layout.eq_items_view, parent, false);
        }
    //    TextView eqMagnitude = (TextView) convertView.findViewById(R.id.eqMagnitude);
   //     TextView eqDepth = (TextView) convertView.findViewById(R.id.eqDepth);
        TextView eqLatLong = (TextView) convertView.findViewById(R.id.eqLatLong);
        TextView eqLocation = (TextView) convertView.findViewById(R.id.eqLocation);
        TextView eqDate = (TextView) convertView.findViewById(R.id.eqDate);

        //set the text view
        eqDate.setText(eAllEQ.get(position).getPubDate());
        eqLocation.setText(eAllEQ.get(position).getLocation());
        eqLatLong.setText(eAllEQ.get(position).getLatLong());
   //     eqDepth.setText(eAllEQ.get(position).getDepth());
    //    eqMagnitude.setText(eAllEQ.get(position).getMagnitude());

        return convertView;
    }

}//end of java class
