//Name: Christopher Fotheringham
//Student ID:S1712624
//Course: BSC Computing

package mpd.cfothe200.S1712624;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

public class pullparse {

    LinkedList<Earthquake> allEQ;
    private Earthquake earthquake;
    private String text;

    public pullparse (){
        allEQ = new LinkedList<>();

        //log statement to find errors
        Log.e("pullparser cons", "item Element");

    }

    //get every earthquake


    public LinkedList<Earthquake> parse(String pDataToParse){
        //declare variables

        Boolean quakeStart = false;
        XmlPullParserFactory factory;
        XmlPullParser pparser;

        //try and catch

        try {

            factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);

            pparser= factory.newPullParser();
            pparser.setInput(new StringReader(pDataToParse));

            int eventType = pparser.getEventType();

            //case statement

            while (eventType != XmlPullParser.END_DOCUMENT){
                String tagname = pparser.getName();

                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if (tagname.equalsIgnoreCase( "item")){
                            earthquake= new Earthquake();
                            Log.e("HERE","item element");
                            Log.e("HERE","item element");
                            Log.e("HERE","item element");
                            Log.e("HERE","item element");
                            Log.e("HERE","item element");
                        }
                        break;
                    case XmlPullParser.TEXT:

                        text = pparser.getText();
                        break;

                    case XmlPullParser.END_TAG:
                        if (tagname.equalsIgnoreCase("image")){
                            quakeStart = true;
                        }
                        else if (tagname.equalsIgnoreCase("item")){
                            allEQ.add(earthquake);
                        }
                        else if (tagname.equalsIgnoreCase("title") &&quakeStart == true) {
                            earthquake.setTitle(text);
                        }
                        else if (tagname.equalsIgnoreCase("description") &&quakeStart == true) {

                            //parsedescription

                             String temp = text;
                             String[] array = temp.split(";");

                             //location
                             earthquake.setLocation(array[1].substring(11));


                             //latitude and longitude
                             earthquake.setLatLong(array[2].substring(11));


                             //depth
                             earthquake.setDepth(array[3].substring(7));

                             //Magnitude
                             earthquake.setMagnitude((array[4].substring(11)));


                            earthquake.setDescription(text);
                        }else if (tagname.equalsIgnoreCase("pubdate")){
                            earthquake.setPubDate(text);
                        }else if (tagname.equalsIgnoreCase("category")){
                            earthquake.setCategory(text);
                        }
                        else if (tagname.equalsIgnoreCase("lat")){
                            earthquake.setLatLong(text);
                        }
                        else if (tagname.equalsIgnoreCase("long")){
                            earthquake.setLatLong(earthquake.getLatLong() + " " + text);
                        }

                    default: break;
                }

                eventType = pparser.next();
            }
        }catch (XmlPullParserException ae1){
            //log statement for errors
            Log.e("XmlPullParserExeption", "item element");

        }catch (IOException ae1){
            Log.e("IOException","item element");
        }
        //return allEQ form pullparse
        return allEQ;
    }
}//end of pullparse java
